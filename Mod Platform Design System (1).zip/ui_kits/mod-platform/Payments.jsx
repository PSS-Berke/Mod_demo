/* =====================================================================
   Screen 3 — Payment Requests (the Wednesday draw).
   Editable % complete recalculates amounts live. Retainage auto-calc.
   Blocked rows (missing COI/W-9) can't be approved — compliance guardrail.
   ===================================================================== */

function calcRow(contractAmount, pct, retPct) {
  const earned = contractAmount * (pct / 100);
  const retainage = earned * (retPct / 100);
  const due = earned - retainage;
  const balance = contractAmount - earned;
  return { earned, retainage, due, balance };
}

function PctEditor({ value, onChange, disabled }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <ProgressBar value={value} height={6} color={disabled ? "var(--fg4)" : "var(--primary)"} />
      <div style={{ display: "flex", alignItems: "center", border: "1px solid var(--border-strong)", borderRadius: 7, overflow: "hidden", opacity: disabled ? .5 : 1 }}>
        <input type="number" min={0} max={100} value={value} disabled={disabled}
          onChange={(e) => onChange(Math.max(0, Math.min(100, Number(e.target.value) || 0)))}
          style={{ width: 42, border: "none", outline: "none", textAlign: "right", font: "600 13px var(--font-sans)", color: "var(--fg1)", padding: "5px 2px 5px 6px", background: "transparent" }} />
        <span style={{ fontSize: 12, color: "var(--fg3)", paddingRight: 7 }}>%</span>
      </div>
    </div>
  );
}

function Payments({ company, embedded }) {
  const base = window.MOD.requests.filter((r) => company === "all" || r.company === company);
  const [pcts, setPcts] = useState(() => Object.fromEntries(window.MOD.requests.map((r) => [r.id, r.percentComplete])));
  const [approved, setApproved] = useState({});

  const setPct = (id, v) => setPcts((p) => ({ ...p, [id]: v }));

  const totals = base.reduce((acc, r) => {
    const { due } = calcRow(r.contractAmount, pcts[r.id], r.retainagePct);
    if (r.status !== "blocked") acc.total += due;
    if (r.status === "blocked") acc.blocked += 1; else acc.ready += 1;
    return acc;
  }, { total: 0, blocked: 0, ready: 0 });

  const Th = ({ children, right }) => (
    <th style={{ textAlign: right ? "right" : "left", padding: "11px 16px", fontSize: 12, fontWeight: 600, color: "var(--fg3)", whiteSpace: "nowrap" }}>{children}</th>
  );
  const Money = ({ v, bold, muted }) => (
    <span style={{ fontVariantNumeric: "tabular-nums", fontWeight: bold ? 700 : 500, color: muted ? "var(--fg4)" : "var(--fg1)", fontSize: 13.5 }}>{window.MOD.fmtUSD(v)}</span>
  );

  return (
    <div>
      {!embedded && <PageHeader title="Payment Requests" subtitle="This week's draw — percentage-of-completion with compliance guardrails." />}

      {/* Summary bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 0, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12, padding: "16px 22px", marginBottom: 18, boxShadow: "var(--shadow-sm)" }}>
        <div style={{ paddingRight: 28 }}>
          <div style={{ fontSize: 12.5, color: "var(--fg3)", marginBottom: 4 }}>Total requested this week</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: "var(--fg1)", letterSpacing: "-.02em", fontVariantNumeric: "tabular-nums" }}>{window.MOD.fmtUSD(totals.total)}</div>
        </div>
        <div style={{ width: 1, height: 40, background: "var(--border)" }} />
        <div style={{ display: "flex", gap: 10, paddingLeft: 28 }}>
          <Badge tone="success" icon="check-circle-2">{totals.ready} ready</Badge>
          <Badge tone="danger" icon="lock">{totals.blocked} blocked</Badge>
        </div>
        <div style={{ flex: 1 }} />
        <Button icon="check-check">Approve all ready</Button>
      </div>

      <Card style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)" }}>
            <tr>
              <Th>Contractor</Th>
              <Th>Project</Th>
              <Th right>Contract</Th>
              <Th>% Complete</Th>
              <Th right>Earned</Th>
              <Th right>Retainage (10%)</Th>
              <Th right>Due this request</Th>
              <Th>Status</Th>
            </tr>
          </thead>
          <tbody>
            {base.map((r) => {
              const c = window.MOD.contractorById(r.contractor);
              const p = window.MOD.projectById(r.project);
              const blocked = r.status === "blocked";
              const isApproved = approved[r.id];
              const { earned, retainage, due, balance } = calcRow(r.contractAmount, pcts[r.id], r.retainagePct);
              return (
                <tr key={r.id} style={{ borderBottom: "1px solid var(--border)", background: blocked ? "var(--danger-tint)" : "transparent" }}>
                  <td style={{ padding: "14px 16px" }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: blocked ? "var(--fg3)" : "var(--fg1)" }}>{c.name}</div>
                    <div style={{ fontSize: 12, color: "var(--fg4)" }}>{c.trade}</div>
                  </td>
                  <td style={{ padding: "14px 16px" }}>
                    <div style={{ fontSize: 13.5, color: "var(--fg2)", marginBottom: 3 }}>{p.name}</div>
                    <CompanyTag companyId={r.company} />
                  </td>
                  <td style={{ padding: "14px 16px", textAlign: "right" }}><Money v={r.contractAmount} muted={blocked} /></td>
                  <td style={{ padding: "14px 16px", minWidth: 190 }}>
                    <PctEditor value={pcts[r.id]} onChange={(v) => setPct(r.id, v)} disabled={blocked} />
                  </td>
                  <td style={{ padding: "14px 16px", textAlign: "right" }}><Money v={earned} muted={blocked} /></td>
                  <td style={{ padding: "14px 16px", textAlign: "right" }}>
                    <span style={{ fontVariantNumeric: "tabular-nums", fontSize: 13.5, color: blocked ? "var(--fg4)" : "var(--fg3)" }}>−{window.MOD.fmtUSD(retainage)}</span>
                  </td>
                  <td style={{ padding: "14px 16px", textAlign: "right" }}><Money v={due} bold muted={blocked} /></td>
                  <td style={{ padding: "14px 16px" }}>
                    {blocked ? (
                      <span title={r.blockReason} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <Badge tone="danger" icon="lock">Blocked</Badge>
                      </span>
                    ) : isApproved ? (
                      <Badge tone="primary" icon="check">Approved</Badge>
                    ) : (
                      <Button variant="secondary" size="sm" icon="check" onClick={() => setApproved((a) => ({ ...a, [r.id]: true }))}>Approve</Button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {/* Blocked reason footnote */}
        {base.some((r) => r.status === "blocked") && (
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 16px", background: "var(--surface-2)", borderTop: "1px solid var(--border)" }}>
            <Icon name="info" size={15} color="var(--fg3)" />
            <span style={{ fontSize: 12.5, color: "var(--fg3)" }}>
              Blocked rows are missing a valid COI or W-9 and cannot be approved until compliance is resolved.
            </span>
          </div>
        )}
      </Card>

      <p style={{ fontSize: 12.5, color: "var(--fg4)", marginTop: 12, display: "flex", alignItems: "center", gap: 6 }}>
        <Icon name="zap" size={14} color="var(--warning)" /> Edit any “% Complete” field — earned, retainage, and amount due recalculate instantly.
      </p>
    </div>
  );
}

Object.assign(window, { Payments, calcRow });
