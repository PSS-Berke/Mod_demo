/* =====================================================================
   Screen 4 — Documents: sworn statement list + document view with
   the AI math-check banner (the "money moment").
   ===================================================================== */

function lineMath(line, retPct) {
  const earned = line.override != null ? line.override : line.sched * (line.pct / 100);
  const correctEarned = line.sched * (line.pct / 100);
  const retainage = correctEarned * (retPct / 100);
  const due = correctEarned - retainage;
  return { earned, correctEarned, retainage, due, hasError: line.override != null };
}

function DocList({ onOpen, embedded }) {
  const docs = [
    { d: window.MOD.swornClean, status: "verified" },
    { d: window.MOD.swornError, status: "error" },
  ];
  return (
    <div>
      {!embedded && <PageHeader title="Documents" subtitle="Generated sworn statements with AI-verified line-item math." />}
      <Card style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)" }}>
            <tr>
              {["Document", "Project", "Company", "Date", "AI Check", ""].map((h, i) => (
                <th key={i} style={{ textAlign: "left", padding: "11px 16px", fontSize: 12, fontWeight: 600, color: "var(--fg3)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {docs.map(({ d, status }) => (
              <tr key={d.id} onClick={() => onOpen(d.id)}
                style={{ borderBottom: "1px solid var(--border)", cursor: "pointer" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--surface-2)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                <td style={{ padding: "14px 16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <Icon name="file-text" size={18} color="var(--fg4)" />
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--fg1)" }}>Sworn Contractor Statement</div>
                      <div style={{ fontSize: 12, color: "var(--fg3)" }}>{d.number}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: "14px 16px", fontSize: 13.5, color: "var(--fg2)" }}>{d.project}</td>
                <td style={{ padding: "14px 16px" }}><CompanyTag companyId={d.company} /></td>
                <td style={{ padding: "14px 16px", fontSize: 13.5, color: "var(--fg2)" }}>{d.date}</td>
                <td style={{ padding: "14px 16px" }}>
                  {status === "verified"
                    ? <Badge tone="success" icon="check-circle-2">Verified</Badge>
                    : <Badge tone="danger" icon="alert-triangle">Error found</Badge>}
                </td>
                <td style={{ padding: "14px 16px" }}><Icon name="chevron-right" size={16} color="var(--fg4)" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function VerifyBanner({ doc }) {
  const err = doc.error;
  if (!err) {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 13, padding: "16px 20px", background: "var(--success-tint)", border: "1px solid #BBF7D0", borderRadius: 12, marginBottom: 22 }}>
        <div style={{ width: 38, height: 38, borderRadius: 999, background: "var(--success)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Icon name="check" size={21} color="#fff" strokeWidth={2.6} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "var(--success-fg)" }}>Math verified — all {doc.lines.length} line items check out.</div>
          <div style={{ fontSize: 12.5, color: "var(--success-fg)", opacity: .8, display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
            <Icon name="sparkles" size={13} /> Verified by AI · {doc.date}, 9:14 AM
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 13, padding: "16px 20px", background: "var(--danger-tint)", border: "1px solid #FECACA", borderRadius: 12, marginBottom: 22 }}>
      <div style={{ width: 38, height: 38, borderRadius: 999, background: "var(--danger)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <Icon name="alert-triangle" size={20} color="#fff" strokeWidth={2.4} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "var(--danger-fg)" }}>Math error found — Line {err.line} (Tile Installation)</div>
        <div style={{ fontSize: 13.5, color: "var(--danger-fg)", opacity: .9, marginTop: 3, lineHeight: 1.5 }}>
          Amount earned shows <b>{window.MOD.fmtUSD(err.shown)}</b> but should be <b>{window.MOD.fmtUSD(err.correct)}</b> based on {err.basis}.
          Off by <b>{window.MOD.fmtUSD(err.diff)}</b>.
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <Button variant="danger" size="sm" icon="wand-2">Auto-correct</Button>
          <Button variant="secondary" size="sm" icon="message-square">Flag to contractor</Button>
        </div>
      </div>
      <div style={{ fontSize: 12.5, color: "var(--danger-fg)", opacity: .7, display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
        <Icon name="sparkles" size={13} /> Verified by AI
      </div>
    </div>
  );
}

function SwornDoc({ id, onBack }) {
  const doc = id === "s2" ? window.MOD.swornError : window.MOD.swornClean;
  const co = window.MOD.companyById(doc.company);
  const totals = doc.lines.reduce((acc, l) => {
    const m = lineMath(l, doc.retainagePct);
    acc.sched += l.sched; acc.earned += m.correctEarned; acc.ret += m.retainage; acc.due += m.due;
    return acc;
  }, { sched: 0, earned: 0, ret: 0, due: 0 });

  const Cell = ({ children, right, head, error }) => (
    <td style={{ padding: "9px 14px", textAlign: right ? "right" : "left", fontSize: 13, fontWeight: head ? 600 : 500,
      color: error ? "var(--danger-fg)" : head ? "var(--fg3)" : "var(--fg2)", fontVariantNumeric: "tabular-nums",
      borderBottom: "1px solid var(--border)" }}>{children}</td>
  );

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "var(--fg3)", fontSize: 13.5, fontWeight: 600, cursor: "pointer", padding: 0 }}>
          <Icon name="arrow-left" size={16} /> Back to documents
        </button>
        <div style={{ display: "flex", gap: 8 }}>
          <Button variant="secondary" size="sm" icon="printer">Print</Button>
          <Button variant="secondary" size="sm" icon="download">Download PDF</Button>
        </div>
      </div>

      <VerifyBanner doc={doc} />

      {/* The document */}
      <Card style={{ padding: 0, overflow: "hidden", maxWidth: 880, margin: "0 auto" }}>
        {/* Company header band */}
        <div style={{ padding: "26px 34px", borderBottom: `3px solid ${co.color}`, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
              <Logo size={26} withWord={false} />
              <span style={{ fontSize: 20, fontWeight: 800, color: "var(--fg1)", letterSpacing: "-.01em" }}>{co.name}</span>
            </div>
            <div style={{ fontSize: 12.5, color: "var(--fg3)" }}>Sworn Contractor Statement</div>
          </div>
          <div style={{ textAlign: "right", fontSize: 12.5, color: "var(--fg3)", lineHeight: 1.7 }}>
            <div><span style={{ color: "var(--fg4)" }}>Statement No.</span> <b style={{ color: "var(--fg2)" }}>{doc.number}</b></div>
            <div><span style={{ color: "var(--fg4)" }}>Date</span> <b style={{ color: "var(--fg2)" }}>{doc.date}</b></div>
          </div>
        </div>

        {/* Project meta */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 0, padding: "18px 34px", borderBottom: "1px solid var(--border)", background: "var(--surface-2)" }}>
          {[["Project", doc.project], ["Client", doc.client], ["Location", doc.address]].map(([k, v]) => (
            <div key={k}>
              <div style={{ fontSize: 11, fontWeight: 600, color: "var(--fg4)", textTransform: "uppercase", letterSpacing: ".04em", marginBottom: 3 }}>{k}</div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--fg1)" }}>{v}</div>
            </div>
          ))}
        </div>

        {/* Line items */}
        <div style={{ padding: "8px 20px 20px" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <Cell head>#</Cell>
                <Cell head>Description of Work</Cell>
                <Cell head right>Scheduled Value</Cell>
                <Cell head right>% Compl.</Cell>
                <Cell head right>Earned</Cell>
                <Cell head right>Retainage</Cell>
                <Cell head right>Amount Due</Cell>
              </tr>
            </thead>
            <tbody>
              {doc.lines.map((l) => {
                const m = lineMath(l, doc.retainagePct);
                const isErr = m.hasError;
                return (
                  <tr key={l.n} style={{ background: isErr ? "var(--danger-tint)" : "transparent" }}>
                    <Cell>{l.n}</Cell>
                    <Cell>
                      <span style={{ color: "var(--fg1)", fontWeight: 500 }}>{l.desc}</span>
                      {isErr && <Icon name="alert-triangle" size={13} color="var(--danger)" style={{ marginLeft: 7, verticalAlign: "-2px" }} />}
                    </Cell>
                    <Cell right>{window.MOD.fmtUSD(l.sched)}</Cell>
                    <Cell right>{l.pct}%</Cell>
                    <Cell right error={isErr}>
                      {window.MOD.fmtUSD(m.earned)}
                      {isErr && <span style={{ display: "block", fontSize: 11, color: "var(--danger)", fontWeight: 600 }}>should be {window.MOD.fmtUSD(m.correctEarned)}</span>}
                    </Cell>
                    <Cell right>−{window.MOD.fmtUSD(m.retainage)}</Cell>
                    <Cell right><span style={{ color: "var(--fg1)", fontWeight: 600 }}>{window.MOD.fmtUSD(m.due)}</span></Cell>
                  </tr>
                );
              })}
              {/* Totals */}
              <tr style={{ background: "var(--surface-2)" }}>
                <td colSpan={2} style={{ padding: "12px 14px", fontSize: 13, fontWeight: 700, color: "var(--fg1)" }}>Totals</td>
                <td style={{ padding: "12px 14px", textAlign: "right", fontSize: 13, fontWeight: 700, color: "var(--fg1)", fontVariantNumeric: "tabular-nums" }}>{window.MOD.fmtUSD(totals.sched)}</td>
                <td></td>
                <td style={{ padding: "12px 14px", textAlign: "right", fontSize: 13, fontWeight: 700, color: "var(--fg1)", fontVariantNumeric: "tabular-nums" }}>{window.MOD.fmtUSD(totals.earned)}</td>
                <td style={{ padding: "12px 14px", textAlign: "right", fontSize: 13, fontWeight: 700, color: "var(--fg2)", fontVariantNumeric: "tabular-nums" }}>−{window.MOD.fmtUSD(totals.ret)}</td>
                <td style={{ padding: "12px 14px", textAlign: "right", fontSize: 14, fontWeight: 800, color: co.color, fontVariantNumeric: "tabular-nums" }}>{window.MOD.fmtUSD(totals.due)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { DocList, SwornDoc });
