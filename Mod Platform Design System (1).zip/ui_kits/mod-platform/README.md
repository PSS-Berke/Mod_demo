# Mod Platform — UI Kit

A high-fidelity, clickable recreation of the **Mod operations platform**: a multi-company dashboard built from collapsible module cards. Front-end only, mock data, no backend — a sales-demo-grade prototype.

Open **`index.html`** to run it.

## What it demonstrates

- **Collapsible modules** — Brief, Payments, Contractors, Projects, Documents. Each is a card that shows quick info + actions when collapsed and expands its full content inline.
- **Configurable pages** — Dashboard · Tools · Projects, switched from the left icon rail. **Manage Modules** assigns modules to pages (a module × page toggle matrix).
- **Company toggle** — All · Mod Design · Mod Construction · Mod Partners. Re-filters every module's data and summary live.
- **Brief** — an AI-generated daily briefing with three snapshots (Compliance, Payments, Projects) and live stat tiles.
- **Payments** — editable % complete with live retainage math and blocked-row compliance guardrails.
- **Contractors** — table → contractor card with per-company COI status and the "payments blocked" guardrail.
- **Documents** — sworn-statement list → document view with the AI math-check banner (green "verified" / red "error found").
- **Mod Concierge** — a docked right-side AI panel with scripted, document-sourced answers to the four suggested prompts.

## Architecture

Plain React + Babel in the browser (no build step). Components export to `window` so files share scope.

| File | Responsibility |
|------|----------------|
| `index.html` | Entry point; loads React, Babel, Lucide, tokens, and all components. |
| `data.js` | Mock data (companies, projects, contractors, requests, sworn statements, Concierge responses) on `window.MOD`. |
| `Primitives.jsx` | `Icon` (Lucide wrapper), `Logo`, `Badge`, `Button`, `Avatar`, `ProgressBar`, `Chip`, `Card`, `CompanyTag`. |
| `Shell.jsx` | `CompanyToggle`, `PageHeader`. |
| `LeftRail.jsx` | Slim icon nav rail. |
| `ModuleShell.jsx` | The collapsible module card + `SummaryPill`. |
| `ManageModules.jsx` | Module × page configuration matrix. |
| `Brief.jsx` | AI daily-briefing module. |
| `Contractors.jsx` | Contractors table + contractor detail card. |
| `Payments.jsx` | Payment requests with live math. |
| `Documents.jsx` | Sworn statement list + document + AI banner. |
| `Projects.jsx` | Project cards grid. |
| `Concierge.jsx` | Docked AI assistant panel. |
| `App.jsx` | Module registry, page/assignment state, layout. |

## Notes

- Data resets on refresh (state is in-memory, per the brief — no storage).
- The Concierge uses scripted answers keyed to the four suggested prompts.
- Reordering modules within a page via the drag handle is indicated but not wired; page assignment is fully functional via Manage Modules.
