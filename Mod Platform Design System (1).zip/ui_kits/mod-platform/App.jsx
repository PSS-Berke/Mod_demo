/* =====================================================================
   App — collapsible-module dashboard.
   Modules are collapsible cards; pages hold configurable sets of modules;
   a docked Concierge panel sits on the right. Mirrors the Jetson/PSS UX.
   ===================================================================== */

const PAGES = [
  { id: "dashboard", label: "Dashboard", icon: "layout-grid", subtitle: "All your modules in one place." },
  { id: "tools",     label: "Tools",     icon: "wrench",     subtitle: "Payments, documents, and verification." },
  { id: "projects",  label: "Projects",  icon: "building-2",  subtitle: "Every build, contract, and contractor." },
];

const todayStr = new Date().toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric" });

function App() {
  const M = window.MOD;
  const [page, setPage] = useState("dashboard");
  const [manage, setManage] = useState(false);
  const [company, setCompany] = useState("all");
  const [conciergeOpen, setConciergeOpen] = useState(false);
  const [openContractor, setOpenContractor] = useState(null);
  const [openDoc, setOpenDoc] = useState(null);
  const [expandedMap, setExpandedMap] = useState({ "dashboard:brief": true });
  const [assignment, setAssignment] = useState({
    dashboard: ["brief", "payments", "contractors"],
    tools:     ["payments", "documents"],
    projects:  ["projects", "contractors"],
  });

  const ctx = { company, openContractor, setOpenContractor, openDoc, setOpenDoc, onConcierge: () => setConciergeOpen(true) };

  // ---- Module registry ----
  const MODULES = {
    brief: {
      id: "brief", title: "Brief", subtitle: `AI-generated daily briefing · ${todayStr}`,
      icon: "sunrise", iconTint: "var(--primary-tint)", iconFg: "var(--primary)",
      actions: () => (
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "var(--primary-tint)", color: "var(--primary)", fontWeight: 600, fontSize: 12.5, padding: "5px 11px", borderRadius: 999 }}>Today</span>
      ),
      summary: () => <SummaryPill icon="sparkles">3 snapshots ready</SummaryPill>,
      body: (c) => <Brief company={c.company} onOpenConcierge={c.onConcierge} />,
      expandFull: (c) => c.onConcierge(),
    },
    payments: {
      id: "payments", title: "Payments", subtitle: "Requests, compliance, and verification.",
      icon: "wallet", iconTint: "var(--co-construction-tint)", iconFg: "var(--co-construction)",
      summary: (c) => {
        const reqs = M.requests.filter((r) => c.company === "all" || r.company === c.company);
        const ready = reqs.filter((r) => r.status !== "blocked");
        const blocked = reqs.filter((r) => r.status === "blocked");
        const total = ready.reduce((s, r) => s + r.contractAmount * (r.percentComplete / 100) * (1 - r.retainagePct / 100), 0);
        return (<>
          <SummaryPill icon="circle-dollar-sign">{M.fmtUSD(total)}</SummaryPill>
          <SummaryPill icon="check-circle-2" tone="success">{ready.length} ready</SummaryPill>
          {blocked.length > 0 && <SummaryPill icon="lock" tone="danger">{blocked.length} blocked</SummaryPill>}
        </>);
      },
      body: (c) => <Payments company={c.company} embedded />,
    },
    contractors: {
      id: "contractors", title: "Contractors", subtitle: "Every record, connected — contacts & compliance.",
      icon: "users", iconTint: "var(--co-design-tint)", iconFg: "var(--co-design)",
      summary: (c) => {
        const s = M.stats[c.company] || M.stats.all;
        return (<>
          <SummaryPill icon="users">{s.contractors} contractors</SummaryPill>
          {s.expiring > 0 && <SummaryPill icon="shield-alert" tone="warning">{s.expiring} COIs expiring</SummaryPill>}
        </>);
      },
      body: (c) => c.openContractor
        ? <ContractorCard id={c.openContractor} company={c.company} onBack={() => c.setOpenContractor(null)} onConcierge={c.onConcierge} />
        : <ContractorsTable company={c.company} onOpen={(id) => c.setOpenContractor(id)} />,
    },
    projects: {
      id: "projects", title: "Projects", subtitle: "Proposals, contracts, and progress.",
      icon: "building-2", iconTint: "var(--co-partners-tint)", iconFg: "var(--co-partners)",
      summary: (c) => {
        const s = M.stats[c.company] || M.stats.all;
        return <SummaryPill icon="hammer">{s.projects} active builds</SummaryPill>;
      },
      body: (c) => <Projects company={c.company} embedded />,
    },
    documents: {
      id: "documents", title: "Documents", subtitle: "Generated sworn statements, verified by AI.",
      icon: "file-check-2", iconTint: "var(--warning-tint)", iconFg: "var(--warning)",
      summary: (c) => {
        const s = M.stats[c.company] || M.stats.all;
        const needsReview = c.company === "all" || c.company === "construction" ? 1 : 0;
        return (<>
          <SummaryPill icon="files">{s.docs} this month</SummaryPill>
          {needsReview > 0 && <SummaryPill icon="alert-triangle" tone="danger">{needsReview} needs review</SummaryPill>}
        </>);
      },
      body: (c) => c.openDoc
        ? <SwornDoc id={c.openDoc} onBack={() => c.setOpenDoc(null)} />
        : <DocList onOpen={(id) => c.setOpenDoc(id)} embedded />,
    },
  };

  const moduleList = Object.values(MODULES);
  const currentPage = PAGES.find((p) => p.id === page);
  const moduleIds = assignment[page] || [];

  const toggleExpand = (id) => {
    const key = page + ":" + id;
    setExpandedMap((m) => ({ ...m, [key]: !m[key] }));
  };
  const toggleAssign = (pageId, moduleId) => {
    setAssignment((a) => {
      const list = a[pageId] || [];
      return { ...a, [pageId]: list.includes(moduleId) ? list.filter((x) => x !== moduleId) : [...list, moduleId] };
    });
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg)", fontFamily: "var(--font-sans)" }}>
      <LeftRail
        page={page} onPage={(p) => { setPage(p); setManage(false); }}
        pages={PAGES} onManage={() => setManage(true)} manageActive={manage}
        conciergeOpen={conciergeOpen} onToggleConcierge={() => setConciergeOpen((o) => !o)}
      />

      <main style={{ flex: 1, minWidth: 0, transition: "margin-right .3s cubic-bezier(.4,0,.2,1)", marginRight: conciergeOpen ? "var(--concierge-w)" : 0 }}>
        <div style={{ maxWidth: 1120, margin: "0 auto", padding: "30px 36px 90px" }}>
          {manage ? (
            <ManageModules modules={moduleList} pages={PAGES} assignment={assignment} onToggle={toggleAssign} onClose={() => setManage(false)} />
          ) : (
            <>
              {/* Page header */}
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, marginBottom: 26, flexWrap: "wrap" }}>
                <div>
                  <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 32, fontWeight: 400, letterSpacing: "-.01em", color: "var(--fg1)" }}>{currentPage.label}</h1>
                  <p style={{ margin: "6px 0 0", fontSize: 15, color: "var(--fg3)" }}>{currentPage.subtitle}</p>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                  <CompanyToggle value={company} onChange={setCompany} />
                </div>
              </div>

              {/* Module stack */}
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {moduleIds.length === 0 && (
                  <div style={{ textAlign: "center", padding: "60px 20px", border: "1px dashed var(--border-strong)", borderRadius: 14, color: "var(--fg3)" }}>
                    <Icon name="layout-grid" size={28} color="var(--fg4)" />
                    <p style={{ margin: "12px 0 14px", fontSize: 14 }}>No modules on this page yet.</p>
                    <Button variant="secondary" icon="settings-2" onClick={() => setManage(true)}>Manage modules</Button>
                  </div>
                )}
                {moduleIds.map((id) => {
                  const mod = MODULES[id];
                  if (!mod) return null;
                  const expanded = !!expandedMap[page + ":" + id];
                  return (
                    <ModuleShell key={id} icon={mod.icon} iconTint={mod.iconTint} iconFg={mod.iconFg}
                      title={mod.title} subtitle={mod.subtitle}
                      summary={mod.summary ? mod.summary(ctx) : null}
                      actions={mod.actions ? mod.actions(ctx) : null}
                      expanded={expanded} onToggle={() => toggleExpand(id)}
                      onExpandFull={mod.expandFull ? () => mod.expandFull(ctx) : null}>
                      {mod.body(ctx)}
                    </ModuleShell>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </main>

      <Concierge open={conciergeOpen} docked onClose={() => setConciergeOpen(false)} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
