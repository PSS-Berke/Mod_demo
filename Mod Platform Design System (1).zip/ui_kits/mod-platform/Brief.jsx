/* =====================================================================
   Brief — AI-generated daily briefing module.
   Three snapshot sub-cards (Compliance · Payments · Projects), each with
   a short narrative + stat tiles. Mirrors the reference product's Brief.
   ===================================================================== */

function StatTile({ label, value, trend, caption }) {
  const tcolor = trend === "up" ? "var(--success)" : trend === "down" ? "var(--danger)" : "var(--fg4)";
  const ticon = trend === "up" ? "trending-up" : trend === "down" ? "trending-down" : "minus";
  return (
    <div style={{ border: "1px solid var(--border)", borderRadius: 10, padding: "10px 12px", background: "var(--surface)", minWidth: 0 }}>
      <div style={{ fontSize: 11, color: "var(--fg3)", marginBottom: 5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ fontSize: 18, fontWeight: 700, color: "var(--fg1)", fontVariantNumeric: "tabular-nums", letterSpacing: "-.01em" }}>{value}</span>
        <Icon name={ticon} size={14} color={tcolor} strokeWidth={2.4} />
      </div>
      <div style={{ fontSize: 11, color: "var(--fg4)", marginTop: 3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{caption}</div>
    </div>
  );
}

function BriefSnapshot({ icon, iconColor, title, children, tiles }) {
  return (
    <div style={{ border: "1px solid var(--border)", borderRadius: 12, padding: 18, background: "var(--surface-2)", display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
        <Icon name={icon} size={18} color={iconColor} />
        <span style={{ fontSize: 15, fontWeight: 700, color: "var(--fg1)", whiteSpace: "nowrap" }}>{title}</span>
      </div>
      <p style={{ margin: 0, fontSize: 13, lineHeight: 1.55, color: "var(--fg2)" }}>{children}</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: "auto" }}>
        {tiles.map((t, i) => <StatTile key={i} {...t} />)}
      </div>
    </div>
  );
}

function Brief({ company, onOpenConcierge }) {
  const M = window.MOD;
  const reqs = M.requests.filter((r) => company === "all" || r.company === company);
  const projs = M.projects.filter((p) => company === "all" || p.company === company);
  const ready = reqs.filter((r) => r.status !== "blocked");
  const blocked = reqs.filter((r) => r.status === "blocked");
  const totalReady = ready.reduce((s, r) => s + r.contractAmount * (r.percentComplete / 100) * (1 - r.retainagePct / 100), 0);
  const retHeld = ready.reduce((s, r) => s + r.contractAmount * (r.percentComplete / 100) * (r.retainagePct / 100), 0);
  const s = M.stats[company] || M.stats.all;
  const avgComplete = Math.round(projs.reduce((a, p) => a + p.percentComplete, 0) / (projs.length || 1));
  const contractTotal = projs.reduce((a, p) => a + p.contractValue, 0);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
        <BriefSnapshot icon="shield-alert" iconColor="var(--danger)" title="Compliance Snapshot"
          tiles={[
            { label: "COIs expiring", value: s.expiring, trend: s.expiring ? "down" : "flat", caption: "within 30 days" },
            { label: "Blocked", value: blocked.length, trend: blocked.length ? "down" : "flat", caption: "payment requests" },
            { label: "Docs verified", value: `${s.docs - 1}/${s.docs}`, trend: "up", caption: "this month" },
          ]}>
          {s.expiring} certificate{s.expiring === 1 ? "" : "s"} of insurance expire within 30 days, and {blocked.length} payment request{blocked.length === 1 ? "" : "s"} {blocked.length === 1 ? "is" : "are"} blocked on missing documents — Apex Plumbing's Mod Design COI expired March 1. Clearing these unblocks this week's draw.
        </BriefSnapshot>

        <BriefSnapshot icon="wallet" iconColor="var(--co-construction)" title="Payments Pulse"
          tiles={[
            { label: "Requested", value: M.fmtUSD(totalReady), trend: "up", caption: "ready to approve" },
            { label: "Ready", value: ready.length, trend: "flat", caption: `${blocked.length} blocked` },
            { label: "Retainage", value: M.fmtUSD(retHeld), trend: "flat", caption: "10% held back" },
          ]}>
          This week's draw totals {M.fmtUSD(totalReady)} across {ready.length} ready request{ready.length === 1 ? "" : "s"}, with {M.fmtUSD(retHeld)} held in retainage. Editing percent-complete on the Payments module recalculates every figure live.
        </BriefSnapshot>

        <BriefSnapshot icon="building-2" iconColor="var(--co-partners)" title="Projects Health"
          tiles={[
            { label: "Active", value: s.projects, trend: "up", caption: "in progress" },
            { label: "Avg complete", value: `${avgComplete}%`, trend: "up", caption: "across portfolio" },
            { label: "Contract value", value: M.fmtUSD(contractTotal), trend: "flat", caption: "under management" },
          ]}>
          {s.projects} active build{s.projects === 1 ? "" : "s"} averaging {avgComplete}% complete. Yellowstone Club Residence leads at 86% with $860,000 remaining; Winnetka New Build trails at 22% and warrants a schedule check.
        </BriefSnapshot>
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 4 }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 12.5, color: "var(--fg3)" }}>
          <Icon name="circle-check" size={15} color="var(--success)" /> Generated from your sworn statements, COIs, and project financials.
        </span>
        <Button icon="arrow-up-right" size="sm" onClick={onOpenConcierge}>View full briefing</Button>
      </div>
    </div>
  );
}

Object.assign(window, { Brief, StatTile, BriefSnapshot });
