/* =====================================================================
   Screen 2 — Contractors table + Contractor Card (detail).
   Shows compliance status, per-company COIs, linked projects,
   and the "payments blocked" guardrail.
   ===================================================================== */

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

// Collapse a contractor's COIs into one badge for the table
function coiSummary(c) {
  const entries = Object.entries(c.coi || {});
  if (entries.some(([, v]) => v.status === "expired")) return { tone: "danger", icon: "shield-x", label: "Expired" };
  if (entries.some(([, v]) => v.status === "expiring")) return { tone: "warning", icon: "shield-alert", label: "Expiring soon" };
  return { tone: "success", icon: "shield-check", label: "Valid" };
}
function w9Badge(c) {
  return c.w9 === "on_file"
    ? { tone: "success", icon: "check", label: "On file" }
    : { tone: "danger", icon: "x", label: "Missing" };
}

function ContractorsTable({ company, onOpen }) {
  const [sort, setSort] = useState({ key: "name", dir: 1 });
  const [q, setQ] = useState("");
  let rows = window.MOD.contractors.filter((c) =>
    company === "all" ? true : !!(c.coi && c.coi[company]) || c.projects.some((pid) => {
      const p = window.MOD.projectById(pid); return p && p.company === company;
    })
  );
  if (q) rows = rows.filter((c) => (c.name + c.trade).toLowerCase().includes(q.toLowerCase()));
  rows = [...rows].sort((a, b) => {
    const av = a[sort.key], bv = b[sort.key];
    return (av > bv ? 1 : av < bv ? -1 : 0) * sort.dir;
  });
  const toggleSort = (key) => setSort((s) => ({ key, dir: s.key === key ? -s.dir : 1 }));
  const Th = ({ k, children, w }) => (
    <th onClick={k ? () => toggleSort(k) : undefined}
      style={{ textAlign: "left", padding: "11px 16px", fontSize: 12, fontWeight: 600, color: "var(--fg3)", cursor: k ? "pointer" : "default", userSelect: "none", whiteSpace: "nowrap", width: w }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
        {children}
        {k && sort.key === k && <Icon name={sort.dir === 1 ? "chevron-up" : "chevron-down"} size={13} />}
      </span>
    </th>
  );

  return (
    <Card style={{ overflow: "hidden" }}>
      {/* Toolbar */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ position: "relative", flex: 1, maxWidth: 280 }}>
          <Icon name="search" size={15} color="var(--fg4)" style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)" }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search contractors…"
            style={{ width: "100%", padding: "8px 12px 8px 32px", border: "1px solid var(--border-strong)", borderRadius: 8, font: "400 13px var(--font-sans)", color: "var(--fg1)", outline: "none", boxSizing: "border-box" }} />
        </div>
        <div style={{ flex: 1 }} />
        <Button variant="secondary" size="sm" icon="sliders-horizontal">Filters</Button>
        <Button variant="secondary" size="sm" icon="download">Export</Button>
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)" }}>
          <tr>
            <Th k="name">Contractor</Th>
            <Th k="trade">Trade</Th>
            <Th>COI</Th>
            <Th>W-9</Th>
            <Th>Agreement</Th>
            <Th>Projects</Th>
            <th style={{ width: 40 }}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((c) => {
            const coi = coiSummary(c), w9 = w9Badge(c);
            const sub = c.subAgreement === "signed" ? { tone: "success", label: "Signed" } : { tone: "warning", label: "Pending" };
            return (
              <tr key={c.id} onClick={() => onOpen(c.id)}
                style={{ borderBottom: "1px solid var(--border)", cursor: "pointer", transition: "background .12s" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--surface-2)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                <td style={{ padding: "13px 16px" }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "var(--fg1)" }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: "var(--fg3)" }}>{c.contact.name}</div>
                </td>
                <td style={{ padding: "13px 16px", fontSize: 13.5, color: "var(--fg2)" }}>{c.trade}</td>
                <td style={{ padding: "13px 16px" }}><Badge tone={coi.tone} icon={coi.icon}>{coi.label}</Badge></td>
                <td style={{ padding: "13px 16px" }}><Badge tone={w9.tone} icon={w9.icon}>{w9.label}</Badge></td>
                <td style={{ padding: "13px 16px" }}><Badge tone={sub.tone}>{sub.label}</Badge></td>
                <td style={{ padding: "13px 16px", fontSize: 13.5, color: "var(--fg2)", fontVariantNumeric: "tabular-nums" }}>{c.projects.length}</td>
                <td style={{ padding: "13px 16px" }}><Icon name="chevron-right" size={16} color="var(--fg4)" /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </Card>
  );
}

/* ---- Contractor detail card ---- */
function CoiRow({ companyId, coi }) {
  const co = window.MOD.companyById(companyId);
  const tone = coi.status === "valid" ? "success" : coi.status === "expiring" ? "warning" : "danger";
  const label = coi.status === "valid" ? `Valid through ${fmtDate(coi.through)}`
    : coi.status === "expiring" ? `Expires ${fmtDate(coi.through)}`
    : `Expired ${fmtDate(coi.through)}`;
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 14px", border: "1px solid var(--border)", borderRadius: 9, background: "var(--surface)" }}>
      <CompanyTag companyId={companyId} />
      <Badge tone={tone} icon={tone === "success" ? "shield-check" : tone === "warning" ? "shield-alert" : "shield-x"}>{label}</Badge>
    </div>
  );
}

function ContractorCard({ id, company, onBack, onConcierge }) {
  const c = window.MOD.contractorById(id);
  const state = window.MOD.complianceState(c);
  const blocked = state === "blocked";
  const w9 = w9Badge(c);

  return (
    <div>
      <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "var(--fg3)", fontSize: 13.5, fontWeight: 600, cursor: "pointer", padding: 0, marginBottom: 16 }}>
        <Icon name="arrow-left" size={16} /> Back to contractors
      </button>

      {/* Header card */}
      <Card style={{ padding: 24, marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ width: 56, height: 56, borderRadius: 13, background: "var(--primary-tint)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Icon name="hard-hat" size={28} color="var(--primary)" strokeWidth={1.8} />
            </div>
            <div>
              <h1 style={{ margin: 0, fontSize: 24, fontWeight: 700, letterSpacing: "-.02em", color: "var(--fg1)" }}>{c.name}</h1>
              <p style={{ margin: "4px 0 12px", fontSize: 14.5, color: "var(--fg3)" }}>{c.trade}</p>
              <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13.5, color: "var(--fg2)" }}>
                  <Icon name="user" size={15} color="var(--fg4)" />{c.contact.name}
                </span>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13.5, color: "var(--fg2)" }}>
                  <Icon name="phone" size={15} color="var(--fg4)" />{c.contact.phone}
                </span>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13.5, color: "var(--fg2)" }}>
                  <Icon name="mail" size={15} color="var(--fg4)" />{c.contact.email}
                </span>
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="secondary" size="sm" icon="phone">Call</Button>
            <Button variant="secondary" size="sm" icon="mail">Email</Button>
          </div>
        </div>
      </Card>

      {/* Guardrail callout */}
      {blocked && (
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 18px", background: "var(--danger-tint)", border: "1px solid #FECACA", borderRadius: 11, marginBottom: 16 }}>
          <Icon name="lock" size={20} color="var(--danger)" />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "var(--danger-fg)" }}>Payments blocked</div>
            <div style={{ fontSize: 13, color: "var(--danger-fg)", opacity: .85 }}>
              {c.w9 === "missing" ? "W-9 is missing. " : ""}
              {Object.entries(c.coi).filter(([, v]) => v.status === "expired").map(([k]) => `COI for ${window.MOD.companyById(k).name} has expired. `).join("")}
              Payment requests are on hold until documents are updated.
            </div>
          </div>
          <Button variant="danger" size="sm" icon="upload">Request docs</Button>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 16 }}>
        {/* Compliance */}
        <Card style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15, fontWeight: 700, color: "var(--fg1)" }}>Compliance</h3>
          <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
            <div style={{ flex: 1, padding: "12px 14px", border: "1px solid var(--border)", borderRadius: 9 }}>
              <div style={{ fontSize: 12, color: "var(--fg3)", marginBottom: 6 }}>W-9</div>
              <Badge tone={w9.tone} icon={w9.icon}>{w9.label}</Badge>
            </div>
            <div style={{ flex: 1, padding: "12px 14px", border: "1px solid var(--border)", borderRadius: 9 }}>
              <div style={{ fontSize: 12, color: "var(--fg3)", marginBottom: 6 }}>Sub Agreement</div>
              <Badge tone={c.subAgreement === "signed" ? "success" : "warning"}>{c.subAgreement === "signed" ? "Signed" : "Pending"}</Badge>
            </div>
          </div>
          <div style={{ fontSize: 12, fontWeight: 600, color: "var(--fg3)", marginBottom: 8 }}>Certificates of Insurance — by company</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {Object.entries(c.coi).map(([cid, coi]) => <CoiRow key={cid} companyId={cid} coi={coi} />)}
          </div>
        </Card>

        {/* Linked projects */}
        <Card style={{ padding: 20 }}>
          <h3 style={{ margin: "0 0 14px", fontSize: 15, fontWeight: 700, color: "var(--fg1)" }}>Linked projects</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {c.projects.map((pid) => {
              const p = window.MOD.projectById(pid);
              const balance = p.contractValue - p.paidToDate;
              return (
                <div key={pid} style={{ padding: "12px 14px", border: "1px solid var(--border)", borderRadius: 9 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                    <span style={{ fontSize: 14, fontWeight: 600, color: "var(--fg1)" }}>{p.name}</span>
                    <CompanyTag companyId={p.company} />
                  </div>
                  <div style={{ display: "flex", gap: 18, fontSize: 12.5, color: "var(--fg3)", fontVariantNumeric: "tabular-nums" }}>
                    <span>Contract <b style={{ color: "var(--fg2)" }}>{window.MOD.fmtUSD(p.contractValue)}</b></span>
                    <span>Paid <b style={{ color: "var(--fg2)" }}>{window.MOD.fmtUSD(p.paidToDate)}</b></span>
                    <span>Balance <b style={{ color: "var(--fg2)" }}>{window.MOD.fmtUSD(balance)}</b></span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { ContractorsTable, ContractorCard, fmtDate });
