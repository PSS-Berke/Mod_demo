/* =====================================================================
   Shared UI primitives for the Mod Platform kit.
   - Icon: renders Lucide icons (window.lucide) as React SVG
   - Logo, Badge, Button, IconButton, Avatar, Chip, ProgressBar, Tooltip
   Exported to window for cross-file use.
   ===================================================================== */
const { useState, useRef, useEffect } = React;

/* ---- Lucide icon wrapper. Accepts kebab-case names (e.g. "layout-grid"). ---- */
const _pascal = (s) => s.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join("");
function Icon({ name, size = 18, strokeWidth = 2, color = "currentColor", style, className }) {
  const set = (window.lucide && window.lucide.icons) || {};
  const node = set[name] || set[_pascal(name)];
  if (!node) return null;
  // IconNode shape: ["svg", attrs, [ [tag, attrs], ... ]]
  const children = Array.isArray(node[2]) ? node[2] : node;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round"
      strokeLinejoin="round" style={style} className={className} aria-hidden="true">
      {children.map((child, i) => React.createElement(child[0], { key: i, ...child[1] }))}
    </svg>
  );
}

/* ---- Brand mark: the real ornate Mod "M" (assets/mod-mark.png) ---- */
function Logo({ size = 32, withWord = false, wordColor = "var(--fg1)" }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
      <img src="../../assets/mod-mark.png" alt="Mod Construction" style={{ height: size, width: "auto", display: "block" }} />
      {withWord && (
        <span style={{ fontWeight: 800, fontSize: 17, letterSpacing: ".06em", color: wordColor }}>MOD</span>
      )}
    </div>
  );
}

/* ---- Status badge (pill) ---- */
const BADGE_TONES = {
  success: { bg: "var(--success-tint)", fg: "var(--success-fg)" },
  warning: { bg: "var(--warning-tint)", fg: "var(--warning-fg)" },
  danger:  { bg: "var(--danger-tint)",  fg: "var(--danger-fg)" },
  neutral: { bg: "var(--neutral-tint)", fg: "var(--neutral-fg)" },
  primary: { bg: "var(--primary-tint-2)", fg: "var(--primary-hover)" },
};
function Badge({ tone = "neutral", icon, children, style }) {
  const t = BADGE_TONES[tone] || BADGE_TONES.neutral;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      background: t.bg, color: t.fg, fontWeight: 600, fontSize: 12,
      padding: "3px 9px", borderRadius: 999, lineHeight: 1.4, whiteSpace: "nowrap", ...style,
    }}>
      {icon && <Icon name={icon} size={13} strokeWidth={2.4} />}
      {children}
    </span>
  );
}

/* ---- Company tag (small, color-coded) ---- */
function CompanyTag({ companyId, style }) {
  const c = window.MOD.companyById(companyId);
  if (!c || c.id === "all") return null;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 600,
      color: c.color, ...style,
    }}>
      <span style={{ width: 7, height: 7, borderRadius: 999, background: c.color }} />
      {c.name}
    </span>
  );
}

/* ---- Buttons ---- */
function Button({ variant = "primary", size = "md", icon, iconRight, children, onClick, disabled, style }) {
  const [hov, setHov] = useState(false);
  const pads = size === "sm" ? "7px 12px" : size === "lg" ? "11px 20px" : "9px 16px";
  const fs = size === "sm" ? 13 : 14;
  const variants = {
    primary: { background: hov ? "var(--primary-hover)" : "var(--primary)", color: "#fff", border: "1px solid transparent", boxShadow: "var(--shadow-xs)" },
    secondary: { background: hov ? "var(--surface-3)" : "var(--surface)", color: "var(--fg2)", border: "1px solid var(--border-strong)" },
    ghost: { background: hov ? "var(--surface-3)" : "transparent", color: "var(--fg2)", border: "1px solid transparent" },
    danger: { background: hov ? "var(--danger-fg)" : "var(--danger)", color: "#fff", border: "1px solid transparent" },
  };
  const v = variants[variant] || variants.primary;
  return (
    <button onClick={disabled ? undefined : onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 7,
        font: `600 ${fs}px var(--font-sans)`, padding: pads, borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1, transition: "background .14s, box-shadow .14s, transform .05s", whiteSpace: "nowrap", ...v, ...style,
      }}>
      {icon && <Icon name={icon} size={fs + 2} strokeWidth={2.2} />}
      {children}
      {iconRight && <Icon name={iconRight} size={fs + 2} strokeWidth={2.2} />}
    </button>
  );
}

function IconButton({ icon, onClick, label, badge, size = 18, style }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} aria-label={label} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        position: "relative", width: 38, height: 38, display: "inline-flex", alignItems: "center", justifyContent: "center",
        borderRadius: 10, border: "1px solid transparent", background: hov ? "var(--surface-3)" : "transparent",
        color: "var(--fg2)", cursor: "pointer", transition: "background .14s", ...style,
      }}>
      <Icon name={icon} size={size} strokeWidth={2} />
      {badge != null && (
        <span style={{
          position: "absolute", top: 5, right: 5, minWidth: 16, height: 16, padding: "0 4px",
          background: "var(--danger)", color: "#fff", fontSize: 10, fontWeight: 700, borderRadius: 999,
          display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid var(--surface)",
        }}>{badge}</span>
      )}
    </button>
  );
}

/* ---- Avatar ---- */
function Avatar({ name = "MK", color = "var(--primary)", size = 34 }) {
  const initials = name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: 999, background: color, color: "#fff",
      display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700,
      fontSize: size * 0.4, flexShrink: 0,
    }}>{initials}</div>
  );
}

/* ---- Progress bar ---- */
function ProgressBar({ value = 0, color = "var(--primary)", height = 6, showLabel = false }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 90 }}>
      <div style={{ flex: 1, height, background: "var(--surface-3)", borderRadius: 999, overflow: "hidden" }}>
        <div style={{ width: `${Math.min(100, value)}%`, height: "100%", background: color, borderRadius: 999, transition: "width .3s ease" }} />
      </div>
      {showLabel && <span style={{ fontSize: 12, fontWeight: 600, color: "var(--fg2)", fontVariantNumeric: "tabular-nums", minWidth: 34, textAlign: "right" }}>{value}%</span>}
    </div>
  );
}

/* ---- Chip (suggested prompt / filter) ---- */
function Chip({ children, onClick, icon, active }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        display: "inline-flex", alignItems: "center", gap: 7, textAlign: "left",
        font: "500 13px var(--font-sans)", color: active ? "var(--primary-hover)" : "var(--fg2)",
        background: active ? "var(--primary-tint)" : (hov ? "var(--surface-3)" : "var(--surface)"),
        border: `1px solid ${active ? "var(--primary-tint-2)" : "var(--border)"}`,
        padding: "8px 12px", borderRadius: 999, cursor: "pointer", transition: "all .14s", lineHeight: 1.35,
      }}>
      {icon && <Icon name={icon} size={14} color="var(--fg3)" />}
      {children}
    </button>
  );
}

/* ---- Card shell ---- */
function Card({ children, style, hover, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12,
        boxShadow: hover && hov ? "var(--shadow-lg)" : "var(--shadow-sm)",
        transform: hover && hov ? "translateY(-2px)" : "none",
        transition: "box-shadow .16s, transform .16s", cursor: onClick ? "pointer" : "default", ...style,
      }}>{children}</div>
  );
}

Object.assign(window, { Icon, Logo, Badge, CompanyTag, Button, IconButton, Avatar, ProgressBar, Chip, Card });
