/* =====================================================================
   LeftRail — slim icon navigation rail.
   Logo, "Manage Modules", page switcher, and bottom utilities.
   ===================================================================== */

function RailIcon({ icon, active, onClick, title, tone }) {
  const [hov, setHov] = useState(false);
  const activeBg = tone === "red" ? "var(--primary-tint)" : "var(--primary-tint)";
  const activeFg = "var(--primary)";
  return (
    <button onClick={onClick} title={title} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        width: 44, height: 44, borderRadius: 11, border: "none", cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
        background: active ? activeBg : (hov ? "var(--surface-3)" : "transparent"),
        color: active ? activeFg : "var(--fg3)", transition: "background .14s, color .14s",
      }}>
      <Icon name={icon} size={21} strokeWidth={active ? 2.3 : 2} />
    </button>
  );
}

function LeftRail({ page, onPage, pages, onManage, manageActive, conciergeOpen, onToggleConcierge }) {
  return (
    <aside style={{
      width: 76, flexShrink: 0, background: "var(--surface)", borderRight: "1px solid var(--border)",
      display: "flex", flexDirection: "column", alignItems: "center", padding: "16px 0 14px",
      position: "sticky", top: 0, height: "100vh",
    }}>
      <div title="Mod Construction" style={{ marginBottom: 12 }}>
        <Logo size={30} />
      </div>

      <button onClick={onManage} style={{
        background: "none", border: "none", cursor: "pointer", color: "var(--primary)", fontWeight: 600,
        fontSize: 11, lineHeight: 1.25, textAlign: "center", padding: "2px 6px 14px", width: 72,
      }}>Manage<br />Modules</button>

      <div style={{ display: "flex", flexDirection: "column", gap: 4, width: "100%", alignItems: "center" }}>
        {pages.map((p) => (
          <RailIcon key={p.id} icon={p.icon} title={p.label} active={!manageActive && page === p.id} onClick={() => onPage(p.id)} />
        ))}
      </div>

      <div style={{ flex: 1 }} />

      <div style={{ display: "flex", flexDirection: "column", gap: 4, width: "100%", alignItems: "center" }}>
        <RailIcon icon="sparkles" title="Mod Concierge" active={conciergeOpen} onClick={onToggleConcierge} />
        <RailIcon icon="settings" title="Settings" />
        <div style={{ width: 28, height: 1, background: "var(--border)", margin: "6px 0" }} />
        <div title="Karl M. — Owner" style={{ marginBottom: 2 }}>
          <Avatar name="Karl M" color="var(--primary)" size={34} />
        </div>
      </div>
    </aside>
  );
}

Object.assign(window, { LeftRail, RailIcon });
