/* =====================================================================
   App shell: TopNav (logo, module tabs, +New, bell, avatar)
   and CompanyToggle (the signature pill segmented control).
   ===================================================================== */

const NAV_TABS = [
  { id: "hub",       label: "Hub",        icon: "layout-grid" },
  { id: "payments",  label: "Payments",   icon: "wallet" },
  { id: "projects",  label: "Projects",   icon: "building-2" },
  { id: "documents", label: "Documents",  icon: "file-check-2" },
  { id: "concierge", label: "Concierge",  icon: "sparkles" },
];

function TopNav({ active, onNav, onConcierge, onNew }) {
  return (
    <header style={{
      height: "var(--nav-h)", background: "var(--surface)", borderBottom: "1px solid var(--border)",
      display: "flex", alignItems: "center", padding: "0 24px", gap: 24, position: "sticky", top: 0, zIndex: 40,
    }}>
      <div style={{ cursor: "pointer" }} onClick={() => onNav("hub")}><Logo /></div>

      <nav style={{ display: "flex", alignItems: "center", gap: 2, marginLeft: 8 }}>
        {NAV_TABS.map((t) => {
          const on = active === t.id;
          return (
            <button key={t.id}
              onClick={() => (t.id === "concierge" ? onConcierge() : onNav(t.id))}
              style={{
                display: "flex", alignItems: "center", gap: 7, padding: "8px 13px", borderRadius: 8,
                border: "none", cursor: "pointer", font: "600 14px var(--font-sans)",
                color: on ? "var(--primary)" : "var(--fg2)",
                background: on ? "var(--primary-tint)" : "transparent", transition: "background .14s, color .14s",
              }}
              onMouseEnter={(e) => { if (!on) e.currentTarget.style.background = "var(--surface-3)"; }}
              onMouseLeave={(e) => { if (!on) e.currentTarget.style.background = "transparent"; }}>
              <Icon name={t.icon} size={16} strokeWidth={2.2} />
              {t.label}
            </button>
          );
        })}
      </nav>

      <div style={{ flex: 1 }} />

      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <Button icon="plus" size="sm" onClick={onNew}>New</Button>
        <IconButton icon="bell" label="Notifications" badge={3} />
        <div style={{ width: 1, height: 26, background: "var(--border)", margin: "0 4px" }} />
        <div style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer" }}>
          <Avatar name="Karl M" color="var(--primary)" />
          <div style={{ lineHeight: 1.25 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--fg1)" }}>Karl M.</div>
            <div style={{ fontSize: 11, color: "var(--fg3)" }}>Owner</div>
          </div>
        </div>
      </div>
    </header>
  );
}

/* ---- Company toggle: signature pill segmented control ---- */
function CompanyToggle({ value, onChange }) {
  const companies = window.MOD.companies;
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 2, padding: 4,
      background: "var(--surface-3)", borderRadius: 999, border: "1px solid var(--border)",
    }}>
      {companies.map((c) => {
        const on = value === c.id;
        return (
          <button key={c.id} onClick={() => onChange(c.id)}
            style={{
              display: "inline-flex", alignItems: "center", gap: 7, padding: "6px 14px", borderRadius: 999,
              border: "none", cursor: "pointer", font: "600 13px var(--font-sans)", whiteSpace: "nowrap",
              color: on ? (c.id === "all" ? "var(--fg1)" : c.color) : "var(--fg3)",
              background: on ? "var(--surface)" : "transparent",
              boxShadow: on ? "var(--shadow-sm)" : "none", transition: "all .14s",
            }}
            onMouseEnter={(e) => { if (!on) e.currentTarget.style.color = "var(--fg1)"; }}
            onMouseLeave={(e) => { if (!on) e.currentTarget.style.color = "var(--fg3)"; }}>
            {c.id !== "all" && <span style={{ width: 7, height: 7, borderRadius: 999, background: on ? c.color : "var(--fg4)" }} />}
            {c.name}
          </button>
        );
      })}
    </div>
  );
}

/* ---- Page header (title + subtitle + right slot) ---- */
function PageHeader({ title, subtitle, right }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 24, gap: 16, flexWrap: "wrap" }}>
      <div>
        <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 30, fontWeight: 400, letterSpacing: "-.01em", color: "var(--fg1)" }}>{title}</h1>
        {subtitle && <p style={{ margin: "6px 0 0", fontSize: 15, color: "var(--fg3)" }}>{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

Object.assign(window, { TopNav, CompanyToggle, PageHeader, NAV_TABS });
