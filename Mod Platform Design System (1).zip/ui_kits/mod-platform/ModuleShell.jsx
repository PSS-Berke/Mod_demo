/* =====================================================================
   ModuleShell — a collapsible module card.
   Collapsed: icon + title + subtitle on the left, quick-info summary
   and quick actions on the right. Click the chevron to expand the body
   inline. Mirrors the Jetson / PSS dashboard module pattern.
   ===================================================================== */

function GripHandle() {
  return (
    <span title="Drag to reorder" style={{ display: "inline-flex", color: "var(--fg4)", cursor: "grab", padding: "2px" }}>
      <Icon name="grip-vertical" size={18} />
    </span>
  );
}

// A small pill used in collapsed summaries (e.g. "5 ready", "38 contacts")
function SummaryPill({ icon, children, tone }) {
  const color = tone === "danger" ? "var(--danger-fg)" : tone === "warning" ? "var(--warning-fg)" : tone === "success" ? "var(--success-fg)" : "var(--fg2)";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 11px", borderRadius: 999,
      border: "1px solid var(--border)", background: "var(--surface)", fontSize: 12.5, fontWeight: 600, color, whiteSpace: "nowrap",
    }}>
      {icon && <Icon name={icon} size={13} color={color === "var(--fg2)" ? "var(--fg4)" : color} />}
      {children}
    </span>
  );
}

function ModuleShell({ icon, iconTint, iconFg, title, subtitle, summary, actions, expanded, onToggle, onExpandFull, children }) {
  return (
    <div style={{
      background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14,
      boxShadow: expanded ? "var(--shadow-md)" : "var(--shadow-sm)", transition: "box-shadow .16s", overflow: "hidden",
    }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "16px 18px", cursor: "pointer" }} onClick={onToggle}>
        <div style={{ width: 42, height: 42, borderRadius: 11, background: iconTint, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Icon name={icon} size={21} color={iconFg} strokeWidth={2} />
        </div>
        <div style={{ minWidth: 0, flexShrink: 1 }}>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 400, color: "var(--fg1)", letterSpacing: "-.005em", lineHeight: 1.2 }}>{title}</div>
          <div style={{ fontSize: 13, color: "var(--fg3)", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{subtitle}</div>
        </div>

        <div style={{ flex: 1 }} />

        {/* Right cluster — stop propagation so action clicks don't toggle */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }} onClick={(e) => e.stopPropagation()}>
          {!expanded && summary && <div style={{ display: "flex", alignItems: "center", gap: 8 }}>{summary}</div>}
          {actions && <div style={{ display: "flex", alignItems: "center", gap: 8 }}>{actions}</div>}
          {expanded && onExpandFull && <IconButton icon="maximize-2" label="Open full" size={16} onClick={onExpandFull} style={{ width: 34, height: 34 }} />}
          <GripHandle />
          <button onClick={onToggle} aria-label={expanded ? "Collapse" : "Expand"} style={{
            width: 34, height: 34, borderRadius: 9, border: "1px solid var(--border)", background: "var(--surface)",
            display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "var(--fg2)",
          }}>
            <Icon name={expanded ? "chevron-up" : "chevron-down"} size={18} />
          </button>
        </div>
      </div>

      {/* Body */}
      {expanded && (
        <div style={{ borderTop: "1px solid var(--border)", padding: "20px", background: "var(--surface)" }}>
          {children}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ModuleShell, SummaryPill, GripHandle });
