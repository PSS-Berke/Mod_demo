/* =====================================================================
   ManageModules — configure which modules appear on each page.
   A module × page matrix of toggles.
   ===================================================================== */

function Switch({ on, onClick, color = "var(--primary)" }) {
  return (
    <button onClick={onClick} role="switch" aria-checked={on} style={{
      width: 38, height: 22, borderRadius: 999, border: "none", cursor: "pointer", padding: 2,
      background: on ? color : "var(--border-strong)", transition: "background .16s", display: "flex",
      justifyContent: on ? "flex-end" : "flex-start", alignItems: "center",
    }}>
      <span style={{ width: 18, height: 18, borderRadius: 999, background: "#fff", boxShadow: "var(--shadow-sm)", transition: "all .16s" }} />
    </button>
  );
}

function ManageModules({ modules, pages, assignment, onToggle, onClose }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 22 }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 30, fontWeight: 400, letterSpacing: "-.01em", color: "var(--fg1)" }}>Manage Modules</h1>
          <p style={{ margin: "6px 0 0", fontSize: 15, color: "var(--fg3)" }}>Choose which modules appear on each page. Changes apply instantly.</p>
        </div>
        <Button variant="secondary" icon="check" onClick={onClose}>Done</Button>
      </div>

      <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, overflow: "hidden", boxShadow: "var(--shadow-sm)" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "var(--surface-2)", borderBottom: "1px solid var(--border)" }}>
            <tr>
              <th style={{ textAlign: "left", padding: "14px 20px", fontSize: 12, fontWeight: 600, color: "var(--fg3)" }}>Module</th>
              {pages.map((p) => (
                <th key={p.id} style={{ padding: "14px 16px", width: 120 }}>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5 }}>
                    <Icon name={p.icon} size={16} color="var(--fg3)" />
                    <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--fg2)" }}>{p.label}</span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {modules.map((m) => (
              <tr key={m.id} style={{ borderBottom: "1px solid var(--border)" }}>
                <td style={{ padding: "14px 20px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 13 }}>
                    <div style={{ width: 38, height: 38, borderRadius: 10, background: m.iconTint, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Icon name={m.icon} size={19} color={m.iconFg} />
                    </div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--fg1)" }}>{m.title}</div>
                      <div style={{ fontSize: 12.5, color: "var(--fg3)" }}>{m.subtitle}</div>
                    </div>
                  </div>
                </td>
                {pages.map((p) => {
                  const on = (assignment[p.id] || []).includes(m.id);
                  return (
                    <td key={p.id} style={{ textAlign: "center", padding: "14px 16px" }}>
                      <div style={{ display: "flex", justifyContent: "center" }}>
                        <Switch on={on} onClick={() => onToggle(p.id, m.id)} />
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ fontSize: 12.5, color: "var(--fg4)", marginTop: 14, display: "flex", alignItems: "center", gap: 6 }}>
        <Icon name="info" size={14} /> A module can live on more than one page. Drag the handle on any module to reorder it within a page.
      </p>
    </div>
  );
}

Object.assign(window, { ManageModules, Switch });
