/* =====================================================================
   Screen 5 — Concierge: slide-in AI assistant panel.
   Friendly intro, suggested prompt chips, scripted document-sourced
   answers with a brief typing delay, chat input with mic + send.
   ===================================================================== */

// Render **bold** and newlines / bullets into React nodes
function renderRich(text) {
  return text.split("\n").map((line, li) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map((seg, i) =>
      seg.startsWith("**") ? <b key={i} style={{ color: "var(--fg1)", fontWeight: 700 }}>{seg.slice(2, -2)}</b> : <span key={i}>{seg}</span>
    );
    const bullet = line.trim().startsWith("•");
    return (
      <div key={li} style={{ paddingLeft: bullet ? 14 : 0, textIndent: bullet ? -14 : 0, marginTop: li ? 4 : 0 }}>
        {parts}
      </div>
    );
  });
}

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: 4, padding: "10px 14px" }}>
      {[0, 1, 2].map((i) => (
        <span key={i} style={{
          width: 7, height: 7, borderRadius: 999, background: "var(--fg4)",
          animation: `modblink 1.2s ${i * 0.18}s infinite ease-in-out`,
        }} />
      ))}
    </div>
  );
}

function Concierge({ open, onClose, docked }) {
  const [messages, setMessages] = useState([]);   // {role, text, source}
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);
  const data = window.MOD.concierge;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, typing]);

  function ask(q) {
    const match = data.find((d) => d.q.toLowerCase() === q.toLowerCase())
      || data.find((d) => q.toLowerCase().includes("yellowstone") && d.q.includes("Yellowstone"))
      || data.find((d) => q.toLowerCase().includes("coi") || q.toLowerCase().includes("expire") ? d.q.includes("expire") : false)
      || data.find((d) => q.toLowerCase().includes("margin") && d.q.includes("margin"))
      || data.find((d) => q.toLowerCase().includes("design") && d.q.includes("Mod Design"));
    setMessages((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      if (match) {
        setMessages((m) => [...m, { role: "assistant", text: match.a, source: match.source }]);
      } else {
        setMessages((m) => [...m, { role: "assistant", text: "I can pull that from your records. For this demo, try one of the suggested questions — each is answered straight from a sworn statement or the compliance ledger.", source: null }]);
      }
    }, 480);
  }

  return (
    <>
      {/* Scrim — only in overlay (non-docked) mode */}
      {!docked && (
        <div onClick={onClose} style={{
          position: "fixed", inset: 0, background: "rgba(17,24,39,.32)", backdropFilter: "blur(1px)",
          opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity .25s", zIndex: 60,
        }} />
      )}
      {/* Panel */}
      <aside style={{
        position: "fixed", top: 0, right: 0, height: "100%", width: "var(--concierge-w)", maxWidth: "92vw",
        background: "var(--surface)", borderLeft: "1px solid var(--border)", boxShadow: "var(--shadow-xl)",
        transform: open ? "translateX(0)" : "translateX(100%)", transition: "transform .3s cubic-bezier(.4,0,.2,1)",
        zIndex: 61, display: "flex", flexDirection: "column",
      }}>
        {/* Header */}
        <div style={{ padding: "18px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: "linear-gradient(135deg, var(--primary), #4f46e5)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="sparkles" size={19} color="#fff" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: "var(--fg1)" }}>Mod Concierge</div>
            <div style={{ fontSize: 12, color: "var(--success-fg)", display: "flex", alignItems: "center", gap: 5 }}>
              <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--success)" }} /> Online · reads your records
            </div>
          </div>
          <IconButton icon="x" label="Close" onClick={onClose} />
        </div>

        {/* Body */}
        <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "20px" }}>
          {messages.length === 0 && (
            <div>
              <div style={{ textAlign: "center", padding: "8px 0 18px" }}>
                <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--primary-tint)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                  <Icon name="sparkles" size={26} color="var(--primary)" />
                </div>
                <div style={{ fontSize: 17, fontWeight: 700, color: "var(--fg1)" }}>Hello — I'm your Mod assistant.</div>
                <div style={{ fontSize: 13.5, color: "var(--fg3)", marginTop: 4 }}>Ask me anything across all three companies.</div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: "var(--fg3)", margin: "8px 0 10px" }}>Try asking</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {data.map((d) => (
                  <Chip key={d.q} icon="corner-down-right" onClick={() => ask(d.q)}>{d.q}</Chip>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {messages.map((m, i) => m.role === "user" ? (
              <div key={i} style={{ alignSelf: "flex-end", maxWidth: "85%", background: "var(--primary)", color: "#fff", padding: "10px 14px", borderRadius: "14px 14px 4px 14px", fontSize: 13.5, lineHeight: 1.45 }}>
                {m.text}
              </div>
            ) : (
              <div key={i} style={{ alignSelf: "flex-start", maxWidth: "92%" }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <div style={{ width: 26, height: 26, borderRadius: 8, background: "var(--primary-tint)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2 }}>
                    <Icon name="sparkles" size={14} color="var(--primary)" />
                  </div>
                  <div style={{ background: "var(--surface-2)", border: "1px solid var(--border)", padding: "12px 14px", borderRadius: "4px 14px 14px 14px", fontSize: 13.5, lineHeight: 1.5, color: "var(--fg2)" }}>
                    {renderRich(m.text)}
                    {m.source && (
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 10, paddingTop: 9, borderTop: "1px solid var(--border)", fontSize: 11.5, color: "var(--fg4)" }}>
                        <Icon name="file-text" size={12} /> Source: {m.source}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {typing && (
              <div style={{ alignSelf: "flex-start", display: "flex", gap: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: 8, background: "var(--primary-tint)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon name="sparkles" size={14} color="var(--primary)" />
                </div>
                <div style={{ background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: 12 }}><TypingDots /></div>
              </div>
            )}
          </div>
        </div>

        {/* Composer */}
        <div style={{ padding: "14px 16px", borderTop: "1px solid var(--border)" }}>
          <form onSubmit={(e) => { e.preventDefault(); if (input.trim()) ask(input.trim()); }}
            style={{ display: "flex", alignItems: "center", gap: 8, border: "1px solid var(--border-strong)", borderRadius: 12, padding: "6px 6px 6px 14px", background: "var(--surface)" }}>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about a project, contractor, or payment…"
              style={{ flex: 1, border: "none", outline: "none", font: "400 13.5px var(--font-sans)", color: "var(--fg1)", background: "transparent" }} />
            <IconButton icon="mic" label="Voice input" size={17} style={{ width: 34, height: 34 }} />
            <button type="submit" style={{
              width: 34, height: 34, borderRadius: 9, border: "none", background: "var(--primary)", color: "#fff",
              display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0,
            }}><Icon name="arrow-up" size={17} color="#fff" strokeWidth={2.4} /></button>
          </form>
          <div style={{ fontSize: 11, color: "var(--fg4)", textAlign: "center", marginTop: 8 }}>Mod Concierge reads your sworn statements, COIs, and project financials.</div>
        </div>
      </aside>
    </>
  );
}

Object.assign(window, { Concierge });
