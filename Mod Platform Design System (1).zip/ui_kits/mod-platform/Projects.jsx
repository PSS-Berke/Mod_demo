/* =====================================================================
   Projects — proposals, contracts, and progress. (Nav tab view.)
   ===================================================================== */

function Projects({ company, embedded }) {
  const rows = window.MOD.projects.filter((p) => company === "all" || p.company === company);
  return (
    <div>
      {!embedded && <PageHeader title="Projects" subtitle="Proposals, contracts, and progress across every active build." />}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
        {rows.map((p) => {
          const balance = p.contractValue - p.paidToDate;
          const co = window.MOD.companyById(p.company);
          const done = p.percentComplete === 100;
          return (
            <Card key={p.id} hover style={{ padding: 20, display: "flex", flexDirection: "column", gap: 14 }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                <CompanyTag companyId={p.company} />
                {done
                  ? <Badge tone="success" icon="check-circle-2">Complete</Badge>
                  : <Badge tone="primary">{p.percentComplete}% complete</Badge>}
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "var(--fg1)", letterSpacing: "-.01em", lineHeight: 1.25 }}>{p.name}</h3>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 5, fontSize: 12.5, color: "var(--fg3)" }}>
                  <Icon name="map-pin" size={13} color="var(--fg4)" /> {p.address} · {p.client}
                </div>
              </div>
              <ProgressBar value={p.percentComplete} color={co.color} showLabel />
              <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 13, borderTop: "1px solid var(--border)" }}>
                {[["Contract", p.contractValue], ["Paid", p.paidToDate], ["Balance", balance]].map(([k, v]) => (
                  <div key={k}>
                    <div style={{ fontSize: 11, color: "var(--fg4)", marginBottom: 2 }}>{k}</div>
                    <div style={{ fontSize: 13.5, fontWeight: 700, color: "var(--fg1)", fontVariantNumeric: "tabular-nums" }}>{window.MOD.fmtUSD(v)}</div>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { Projects });
