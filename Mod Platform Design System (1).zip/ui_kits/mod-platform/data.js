/* =====================================================================
   Mock data for the Mod Platform prototype.
   Front-end only. Realistic, construction-flavored, anonymized.
   Exposed on window.MOD.
   ===================================================================== */
(function () {
  const companies = [
    { id: "all",          name: "All",              short: "All",  color: "var(--co-all)",          tint: "var(--co-all-tint)" },
    { id: "design",       name: "Mod Design",       short: "Design", color: "var(--co-design)",      tint: "var(--co-design-tint)" },
    { id: "construction", name: "Mod Construction", short: "Construction", color: "var(--co-construction)", tint: "var(--co-construction-tint)" },
    { id: "partners",     name: "Mod Partners",     short: "Partners", color: "var(--co-partners)",   tint: "var(--co-partners-tint)" },
  ];

  // Dashboard stats per company
  const stats = {
    all:          { projects: 12, contractors: 84, requests: 23, expiring: 3, docs: 47 },
    design:       { projects: 4,  contractors: 21, requests: 6,  expiring: 1, docs: 12 },
    construction: { projects: 6,  contractors: 52, requests: 14, expiring: 2, docs: 28 },
    partners:     { projects: 2,  contractors: 11, requests: 3,  expiring: 0, docs: 7  },
  };

  const projects = [
    { id: "p1", name: "Yellowstone Club Residence", company: "construction", client: "Private Client A", address: "Big Sky, MT",     contractValue: 6100000, paidToDate: 5240000, percentComplete: 86 },
    { id: "p2", name: "Lake Forest Estate",         company: "construction", client: "Private Client B", address: "Lake Forest, IL", contractValue: 3450000, paidToDate: 1380000, percentComplete: 40 },
    { id: "p3", name: "Gold Coast Penthouse — Interiors", company: "design",  client: "Private Client C", address: "Chicago, IL",    contractValue: 890000,  paidToDate: 712000,  percentComplete: 80 },
    { id: "p4", name: "Winnetka New Build",         company: "construction", client: "Private Client D", address: "Winnetka, IL",   contractValue: 4200000, paidToDate: 945000,  percentComplete: 22 },
    { id: "p5", name: "Aspen Retreat — Design",     company: "design",       client: "Private Client E", address: "Aspen, CO",      contractValue: 1250000, paidToDate: 1250000, percentComplete: 100 },
    { id: "p6", name: "Hinsdale Renovation",        company: "partners",     client: "Private Client F", address: "Hinsdale, IL",   contractValue: 760000,  paidToDate: 228000,  percentComplete: 30 },
  ];

  const contractors = [
    { id: "c1", name: "Apex Plumbing", trade: "Plumbing",
      contact: { name: "Tom Reilly", phone: "(312) 555-0142", email: "tom@apexplumbing.com" },
      coi: { construction: { status: "valid", through: "2026-09-15" }, design: { status: "expired", through: "2026-03-01" } },
      w9: "on_file", subAgreement: "signed", projects: ["p1", "p3"] },

    { id: "c2", name: "Meridian Electric", trade: "Electrical",
      contact: { name: "Dana Cole", phone: "(312) 555-0188", email: "dana@meridianelec.com" },
      coi: { construction: { status: "expiring", through: "2026-06-09" } },
      w9: "on_file", subAgreement: "signed", projects: ["p1", "p2", "p4"] },

    { id: "c3", name: "Heritage Millwork", trade: "Custom Millwork",
      contact: { name: "Sam Ford", phone: "(847) 555-0210", email: "sam@heritagemill.com" },
      coi: { construction: { status: "valid", through: "2027-01-20" } },
      w9: "missing", subAgreement: "pending", projects: ["p2", "p3"] },

    { id: "c4", name: "Crystal Glass & Glazing", trade: "Glazing",
      contact: { name: "Lee Park", phone: "(312) 555-0273", email: "lee@crystalglass.com" },
      coi: { design: { status: "valid", through: "2026-11-30" } },
      w9: "on_file", subAgreement: "signed", projects: ["p3", "p5"] },

    { id: "c5", name: "Summit Steel & Iron", trade: "Structural Steel",
      contact: { name: "Maria Vance", phone: "(312) 555-0319", email: "maria@summitsteel.com" },
      coi: { construction: { status: "valid", through: "2026-12-04" } },
      w9: "on_file", subAgreement: "signed", projects: ["p1", "p4"] },

    { id: "c6", name: "Northshore HVAC", trade: "Mechanical / HVAC",
      contact: { name: "Greg Olsen", phone: "(847) 555-0461", email: "greg@northshorehvac.com" },
      coi: { construction: { status: "valid", through: "2026-08-22" }, partners: { status: "valid", through: "2026-08-22" } },
      w9: "on_file", subAgreement: "signed", projects: ["p4", "p6"] },
  ];

  const requests = [
    { id: "r1", contractor: "c1", project: "p1", company: "construction", contractAmount: 420000, percentComplete: 86, retainagePct: 10, status: "ready" },
    { id: "r2", contractor: "c2", project: "p2", company: "construction", contractAmount: 310000, percentComplete: 40, retainagePct: 10, status: "ready" },
    { id: "r3", contractor: "c3", project: "p2", company: "construction", contractAmount: 185000, percentComplete: 55, retainagePct: 10, status: "blocked", blockReason: "W-9 missing" },
    { id: "r4", contractor: "c4", project: "p3", company: "design",       contractAmount: 96000,  percentComplete: 80, retainagePct: 10, status: "ready" },
    { id: "r5", contractor: "c1", project: "p3", company: "design",       contractAmount: 64000,  percentComplete: 25, retainagePct: 10, status: "blocked", blockReason: "COI expired (Mod Design)" },
    { id: "r6", contractor: "c5", project: "p1", company: "construction", contractAmount: 540000, percentComplete: 70, retainagePct: 10, status: "ready" },
    { id: "r7", contractor: "c6", project: "p6", company: "partners",     contractAmount: 128000, percentComplete: 30, retainagePct: 10, status: "ready" },
  ];

  // Sworn statement line items — Yellowstone (all correct)
  const swornClean = {
    id: "s1", project: "Yellowstone Club Residence", company: "construction",
    client: "Private Client A", address: "Big Sky, MT", date: "May 12, 2026", number: "SS-2026-0431",
    lines: [
      { n: 1,  desc: "Site Preparation & Excavation", sched: 480000, pct: 100, },
      { n: 2,  desc: "Foundation & Concrete",         sched: 620000, pct: 100, },
      { n: 3,  desc: "Structural Framing",            sched: 940000, pct: 100, },
      { n: 4,  desc: "Plumbing Rough-In",             sched: 310000, pct: 95,  },
      { n: 5,  desc: "Electrical Rough-In",           sched: 280000, pct: 92,  },
      { n: 6,  desc: "HVAC Systems",                  sched: 420000, pct: 88,  },
      { n: 7,  desc: "Insulation",                    sched: 160000, pct: 100, },
      { n: 8,  desc: "Drywall & Plaster",             sched: 380000, pct: 80,  },
      { n: 9,  desc: "Tile Installation",             sched: 295000, pct: 70,  },
      { n: 10, desc: "Custom Millwork",               sched: 540000, pct: 65,  },
      { n: 11, desc: "Glazing & Curtain Wall",        sched: 610000, pct: 78,  },
      { n: 12, desc: "Interior Paint & Finishes",     sched: 220000, pct: 55,  },
      { n: 13, desc: "Flooring",                      sched: 340000, pct: 60,  },
      { n: 14, desc: "Fixtures & Final",              sched: 505000, pct: 35,  },
    ],
    retainagePct: 10,
  };

  // Sworn statement with planted error — Lake Forest, Line 7
  const swornError = {
    id: "s2", project: "Lake Forest Estate", company: "construction",
    client: "Private Client B", address: "Lake Forest, IL", date: "May 14, 2026", number: "SS-2026-0438",
    lines: [
      { n: 1,  desc: "Site Preparation & Excavation", sched: 220000, pct: 100 },
      { n: 2,  desc: "Foundation & Concrete",         sched: 340000, pct: 100 },
      { n: 3,  desc: "Structural Framing",            sched: 510000, pct: 80  },
      { n: 4,  desc: "Plumbing Rough-In",             sched: 180000, pct: 60  },
      { n: 5,  desc: "Electrical Rough-In",           sched: 165000, pct: 55  },
      { n: 6,  desc: "HVAC Systems",                  sched: 240000, pct: 45  },
      { n: 7,  desc: "Tile Installation",             sched: 31000,  pct: 40, override: 14200 }, /* should be 12400 */
      { n: 8,  desc: "Drywall & Plaster",             sched: 210000, pct: 30  },
      { n: 9,  desc: "Custom Millwork",               sched: 295000, pct: 20  },
      { n: 10, desc: "Glazing",                       sched: 188000, pct: 25  },
    ],
    retainagePct: 10,
    error: { line: 7, shown: 14200, correct: 12400, basis: "40% of $31,000", diff: 1800 },
  };

  // Concierge canned responses, keyed to chip text
  const concierge = [
    { q: "How much did we pay on the Yellowstone Club project?",
      a: "Based on the most recent sworn contractor statement (dated May 12, 2026), you've paid **$5,240,000** on the Yellowstone Club Residence to date, against a contract value of $6,100,000 — that's **86% complete**, with $860,000 remaining. Want me to break it down by trade?",
      source: "Sworn Statement SS-2026-0431 · Mod Construction" },
    { q: "Which COIs expire this month?",
      a: "Two certificates of insurance need attention within 30 days:\n• **Meridian Electric** (Mod Construction) — expires **June 9**\n• **Apex Plumbing** (Mod Design) — already **expired March 1**; payments are blocked.\nWant me to draft renewal reminders?",
      source: "Compliance ledger · 2 records" },
    { q: "What's our margin on the Lake Forest build?",
      a: "On **Lake Forest Estate**, approved contract value is $3,450,000 against internal costs of $2,760,000 — a margin of **20% ($690,000)**. Labor is running at 18% margin, materials at 23%. Want the line-item breakdown?",
      source: "Project P2 financials · Mod Construction" },
    { q: "Show me open payment requests for Mod Design",
      a: "**Mod Design** has **6 open payment requests** totaling $312,000 this week. One is **blocked**: Apex Plumbing's COI for Mod Design expired March 1. The other 5 are ready to approve.",
      source: "Payments queue · Mod Design" },
  ];

  // ---- Helpers ----
  const fmtUSD = (n) => "$" + Math.round(n).toLocaleString("en-US");
  const fmtUSD0 = (n) => "$" + Math.round(n).toLocaleString("en-US");
  const companyById = (id) => companies.find((c) => c.id === id);
  const contractorById = (id) => contractors.find((c) => c.id === id);
  const projectById = (id) => projects.find((p) => p.id === id);

  // Worst compliance state for a contractor (for guardrail)
  function complianceState(c) {
    const cois = Object.values(c.coi || {});
    const hasExpired = cois.some((x) => x.status === "expired");
    const hasExpiring = cois.some((x) => x.status === "expiring");
    if (hasExpired || c.w9 === "missing") return "blocked";
    if (hasExpiring || c.subAgreement === "pending") return "warning";
    return "ok";
  }

  window.MOD = {
    companies, stats, projects, contractors, requests,
    swornClean, swornError, concierge,
    fmtUSD, fmtUSD0, companyById, contractorById, projectById, complianceState,
  };
})();
