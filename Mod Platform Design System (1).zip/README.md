# Mod Platform — Design System

A design system and clickable prototype for **Mod Construction**, a luxury construction firm that runs three companies — **Mod Design**, **Mod Construction**, and **Mod Partners** — on shared projects. This repo gives a design agent everything it needs to produce on-brand interfaces, documents, and demos for the Mod operations platform.

> **What this is:** a polished, front-end-only operations platform that lets the owner (Karl) and his operations lead (Maryna) find anything in one place — and *ask an AI* and get a specific, document-sourced answer. The single most important moment is the Concierge answering “How much did we pay on the Yellowstone Club project?” with a real number pulled from a sworn statement.

---

## Sources

This system was built from a written build brief (no prior UI code existed — the design notes below *are* the source of truth). Explore the originals to go deeper:

- **GitHub — build spec:** https://github.com/PSS-Berke/Mod_demo
  - `01-BUILD-BRIEF.md` — product, audience, constraints, tech stack, the five screens
  - `02-SCREEN-MAP.md` — per-screen layout, components, behavior
  - `03-MOCK-DATA-SPEC.md` — companies, projects, contractors, requests, sworn statements, Concierge responses
  - `04-DESIGN-NOTES.md` — target aesthetic, color, type, recurring components
- **Referenced sibling products** (visual DNA the MVP should share — request access if needed):
  - `PSS-Berke/Jetson` — Jetson marketing services tool
  - `PSS-Berke/PSS` — the Parallel Strategies platform

If you have access to the repos above, read them to build more faithful designs. Everything in this system is anonymized, fictional, and front-end-only — no real client data, no backend.

---

## The product at a glance

A multi-company operations platform with five core surfaces:

| # | Screen | Job |
|---|--------|-----|
| 1 | **Hub Dashboard** | Landing view: summary stats + module cards. Establishes the multi-company concept via the company toggle. |
| 2 | **Contractor Card** | One place for a contractor's compliance (COI per company, W-9, sub agreement), linked projects, and the "payments blocked" guardrail. |
| 3 | **Payments / Requests** | The weekly draw: editable % complete with live retainage math and compliance guardrails on blocked rows. |
| 4 | **Sworn Statement + AI Math Check** | A generated document with a prominent AI verification banner — green "verified" or red "error found" with a specific, reasoned explanation. |
| 5 | **Concierge** | A slide-in AI assistant that answers questions with specific, document-sourced figures. The emotional centerpiece. |

**Signature interactions:**
- **Collapsible modules on configurable pages.** Instead of separate full-page tabs, each surface (Brief, Payments, Contractors, Projects, Documents) is a **collapsible module card** stacked on a scrolling page. Collapsed, a module shows quick info + quick actions on the right (e.g. *“$880,560 · 5 ready · 2 blocked”*); click the chevron to expand its full content inline. Pages — **Dashboard · Tools · Projects** — are switched from a slim left icon rail, and **Manage Modules** lets you choose which modules appear on which page.
- **The company toggle** — a pill segmented control (All · Mod Design · Mod Construction · Mod Partners) at the top-right of every page. Toggling it re-filters every module's data and summary live. This sells the multi-entity story.
- **A docked Mod Concierge** — the AI assistant lives in a right-side panel toggled from the rail; it pushes content aside rather than overlaying.

---

## CONTENT FUNDAMENTALS

How copy is written across the product, documents, and the Concierge.

- **Voice:** confident, precise, operational. Speaks the customer's language — *sworn statements, retainage, draws, COI, W-9, % complete, line items, trades*. Never generic SaaS filler.
- **Specific over round.** Numbers are exact: `$5,240,000`, `86% complete`, `$860,000 remaining`, `Off by $1,800`. Precision is the product's credibility. Never use `$5M` or "about 86%".
- **Person:** addresses the user as **you** ("All your companies, all your work"). The Concierge speaks in first person ("Hello — I'm your Mod assistant"). Warm but businesslike.
- **Casing:** Sentence case for body, subtitles, and table cells. Title Case for nav tabs, button labels, and page titles ("Payment Requests"). UPPERCASE only for tiny labels/eyebrows (`OPEN PAYMENT REQUESTS`), tracked +.04em.
- **Privacy/discretion theme:** clients are always anonymized — *Private Client A*, *Private Client B*. This reflects the luxury clientele who value discretion. Never invent named clients.
- **Concierge answers** follow a pattern: lead with the specific figure (bolded), give the supporting context (contract value, % complete, balance), cite the source ("Based on the most recent sworn contractor statement, dated May 12, 2026…"), and end with a helpful follow-up offer ("Want me to break it down by trade?").
- **Status language is plain and human:** "Valid through Sep 15, 2026", "Expires June 9", "Expired March 1 — payments blocked", "W-9 missing".
- **No emoji.** This is enterprise software for people building $6M homes. The tone is premium and restrained. (The brief's prose uses ⚠ as shorthand, but in the UI use the amber/red status system and Lucide icons instead.)

**Example copy:**
> *"All your companies, all your work — in one place."* (Dashboard subtitle)
> *"Math error found — Line 7 (Tile Installation): amount earned shows $14,200 but should be $12,400 based on 40% of $31,000. Off by $1,800."* (AI banner)
> *"Mod Design has 6 open payment requests totaling $312,000 this week. One is blocked: Apex Plumbing's COI for Mod Design expired March 1."* (Concierge)

---

## VISUAL FOUNDATIONS

The look: **light, airy, premium enterprise SaaS.** Nothing wireframe-y, nothing cramped, nothing flat-gray. These clients build luxury homes — the tool should feel luxury too.

- **Color & vibe.** White (`#FFFFFF`) surfaces on a very-light-gray canvas (`#F7F8FA`). A single **Parallel Strategies red** accent (`#C0392B`) for active states, primary buttons (Add, View), key actions, and “Manage Modules” — matching the live Jetson / PSS product. Status system: green good (`#16A34A`), amber warning (`#D97706`), red error (`#DC2626`), each with a soft tint background for badges/banners. The three companies each carry an identity color (Design = blue, Construction = green, Partners = purple) shown as a small dot + label. Restrained, never more than one accent dominating a view.
- **Typography.** A two-family system. **Absans** (`--font-display`) — the Mod brand display face, a single Regular weight — sets all titles (page titles, module titles) and the wordmark; hierarchy comes from size, not weight. **Inter** (`--font-sans`) carries all UI and body text, where weights 400–700 keep dense tables and labels legible. Dollar figures and percentages use **tabular lining numerals** so columns align. Base size 14px (enterprise density), titles 18–34px.
- **Spacing & layout.** 4px base scale. Generous whitespace. A slim left icon rail (76px) holds the logo, “Manage Modules”, the page switcher, and bottom utilities (Concierge, settings, avatar). Content max-width ~1120px, centered. The company toggle sits top-right of every page. The docked Concierge panel (~408px) slides in from the right and pushes content aside (no scrim when docked).
- **Backgrounds.** Solid and clean — white surfaces, light-gray canvas. **No photographic or illustrated backgrounds, no busy textures.** The one tasteful exception is the dark Concierge promo tile and floating launcher, which use a subtle dark gradient (`#111827 → #1f2937`) to make the AI feel premium. Documents use a colored top border-band keyed to the company.
- **Cards.** White, `border-radius: 12px`, hairline border (`#E5E7EB`), soft low-spread shadow (`shadow-sm`). On hover, clickable cards lift 2px and deepen to `shadow-lg`. Module/stat cards pair a tinted rounded icon tile (light accent tint) with bold title + gray description.
- **Borders & dividers.** 1px `#E5E7EB` hairlines everywhere — table row separators, card edges, section dividers. Inputs use a slightly stronger `#D1D5DB`.
- **Corner radii.** 6px chips/inputs, 8px buttons, 12px cards, 16px panels, full (999px) for pills/badges/avatars/toggle.
- **Shadows / elevation.** Soft, neutral, low-spread (`rgba(16,24,40,.04–.14)`). Five steps from `xs` (hairline lift) to `xl` (floating launcher / Concierge panel). Never harsh or colored.
- **Transparency & blur.** Used sparingly: the Concierge scrim is `rgba(17,24,39,.32)` with a faint `backdrop-filter: blur(1px)`. No frosted-glass everywhere — surfaces are opaque.
- **Animation.** Quick and purposeful. Hover background/elevation transitions ~140ms. The Concierge panel slides in over 300ms on `cubic-bezier(.4,0,.2,1)`. The assistant shows a 480ms "typing" delay with a 3-dot pulse before answering, so it feels real. No bounces, no flashy entrances.
- **Hover states.** Buttons darken (primary → `#1D4ED8`); ghost/secondary fill with `#F3F4F6`; table rows fill light gray; cards lift. **Press:** color deepens further (primary → `#1E40AF`); no scale-shrink.
- **Imagery color vibe.** N/A — the product is data-and-document-centric, not photographic. Keep it clean and typographic.
- **Protection gradients vs capsules:** badges and the company toggle use solid tinted **capsules** (pills), not gradient overlays. The only gradients are the two dark AI surfaces noted above.

---

## ICONOGRAPHY

- **Icon set: [Lucide](https://lucide.dev).** This is exactly what the build brief specifies (`lucide-react`). The prototype loads Lucide via CDN (`lucide@0.460.0` UMD) and renders icons as inline SVG through a small React `<Icon>` wrapper (see `ui_kits/mod-platform/Primitives.jsx`) that accepts kebab-case names (`layout-grid`, `shield-alert`). The preview cards use `<i data-lucide="…">` + `lucide.createIcons()`. **No substitution was needed** — Lucide is the real, intended set.
- **Style:** Lucide's clean 2px-stroke, rounded-cap, 24×24 outline icons. Sized 13–22px in UI. Stroke weight bumps to ~2.2–2.6 only for small filled status circles (e.g. the check inside the green AI banner badge).
- **Common icons:** `layout-grid` (Hub), `wallet` (Payments), `building-2` (Projects), `file-check-2` (Documents), `sparkles` (Concierge / AI), `shield-check` / `shield-alert` / `shield-x` (COI status), `lock` (blocked), `check` / `x` (W-9), `hard-hat` (contractor), `mic` / `arrow-up` (composer), `bell`, `plus`, `search`, `download`, `chevron-*`, `arrow-*`.
- **Emoji:** none. Status meaning is carried by color + Lucide icon, never emoji.
- **Unicode as icon:** only the en-dash/em-dash in copy and the `−` minus sign for retainage. No unicode glyphs used as functional icons.
- **Logo / mark:** the official Mod Construction logo is now in `assets/`:
  - `assets/mod-logo.png` — the full lockup (the ornate red **M** above a "MOD CONSTRUCTION" wordmark), transparent PNG. Use in large/standalone spots.
  - `assets/mod-mark.png` — just the ornate red **M**, cropped from the lockup, for compact placements (the left rail, document headers, favicons). The prototype's `<Logo>` component renders this mark.
  - The M is a warm red (`#C0392B` family) on transparent, so it sits cleanly on white surfaces. On dark surfaces it still reads (it's red, not black). The "MOD CONSTRUCTION" wordmark in the full lockup is black — pair the **mark** with a recolorable text wordmark on dark backgrounds.

---

## Tokens

All foundations live in [`colors_and_type.css`](colors_and_type.css) as CSS custom properties:
- Type families (`--font-sans` = Inter, `--font-mono`), the type scale (`--text-xs` … `--text-3xl`), and semantic specimen classes (`.ds-h1`, `.ds-body`, `.ds-money`, …).
- Full color system: neutrals/surfaces, primary blue scale, status (success/warning/danger + tints), company identity colors.
- Radii, a five-step shadow/elevation system, and a 4px spacing scale.

Import it and build with the variables — don't hard-code hex values.

---

## Index — what's in this repo

| Path | What it is |
|------|-----------|
| `README.md` | This file — product context, content + visual foundations, iconography, index. |
| `SKILL.md` | Agent Skill manifest so this system works as a downloadable Claude Skill. |
| `colors_and_type.css` | All design tokens (color + type + spacing + elevation). |
| `preview/*.html` | 18 design-system specimen cards (Type, Colors, Spacing, Components, Brand). |
| `ui_kits/mod-platform/` | The clickable prototype — the full Mod operations platform. See its own README. |
| `ui_kits/mod-platform/index.html` | Entry point. Open this to run the demo. |
| `assets/` | Drop official logos / brand imagery here (currently none supplied). |

### UI kits
- **`ui_kits/mod-platform/`** — the collapsible-module dashboard: a left icon rail, configurable pages (Dashboard · Tools · Projects), and modules for Brief, Payments, Contractors, Projects, and Documents, plus a docked Mod Concierge. Built from small reusable JSX components (`Primitives.jsx`, `Shell.jsx`, `LeftRail.jsx`, `ModuleShell.jsx`, `ManageModules.jsx`, `Brief.jsx`, `Contractors.jsx`, `Payments.jsx`, `Documents.jsx`, `Projects.jsx`, `Concierge.jsx`, `App.jsx`) over mock data in `data.js`. See its own README.

---

## Caveats

- The prototype now matches the **live Jetson / PSS product** pattern the client shared: a collapsible-module dashboard with a left icon rail, configurable pages, and a docked Concierge — mapped onto Mod's domain.
- **Brand assets wired in:** the official Mod Construction logo (`assets/`) and the **Absans** display typeface (`fonts/`). Inter is still loaded from Google Fonts for UI/body text — swap in a licensed/self-hosted copy for production (no local file was supplied).
- The Concierge uses **scripted** answers keyed to the four suggested prompts (no live AI), per the brief's demo requirement.
- Module drag-to-reorder within a page is indicated (drag handle) but not wired; page assignment is fully functional via Manage Modules.
