---
name: mod-design
description: Use this skill to generate well-branded interfaces and assets for Mod Construction (a luxury multi-company construction firm), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, the brand logo, and UI kit components for prototyping the Mod operations platform.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out (the logo in `assets/`, the fonts in `fonts/`, the tokens in `colors_and_type.css`) and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Key facts to load fast:
- **Accent:** Parallel Strategies red (`#C0392B`). Status colors: green/amber/red. Three company identity colors (Design = blue, Construction = green, Partners = purple).
- **Type:** Absans (`--font-display`) for titles & the wordmark; Inter (`--font-sans`) for UI/body.
- **Icons:** Lucide.
- **Signature UX:** collapsible module cards on configurable pages, a company toggle that filters every data view, and a docked "Mod Concierge" AI panel.
- **Logo:** `assets/mod-mark.png` (the ornate red M) for compact spots; `assets/mod-logo.png` (full lockup) for larger ones.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
